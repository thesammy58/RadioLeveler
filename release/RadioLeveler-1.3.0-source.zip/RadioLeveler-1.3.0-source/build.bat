@echo off
rem Builds build\RadioLeveler.asi with Visual Studio (MSVC).
rem Run it from an "x86 Native Tools Command Prompt for VS": the game is 32-bit.
rem Official releases are built with build.sh (llvm-mingw); see README.md.
setlocal
cd /d "%~dp0"
if /i not "%VSCMD_ARG_TGT_ARCH%"=="x86" (
    echo Run this from an x86 Native Tools Command Prompt for VS. The game is 32-bit.
    exit /b 1
)
if not exist build mkdir build
cl /nologo /std:c++17 /O2 /MT /LD /GR- /arch:SSE2 /W3 /D_CRT_SECURE_NO_WARNINGS ^
   /Fobuild\ src\radio_leveler.cpp /link /OUT:build\RadioLeveler.asi /IMPLIB:build\RadioLeveler.lib
if errorlevel 1 exit /b 1
echo Built build\RadioLeveler.asi
