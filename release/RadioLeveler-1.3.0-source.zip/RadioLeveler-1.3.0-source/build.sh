#!/bin/sh
# Builds build/RadioLeveler.asi (32-bit) with MinGW-w64.
#
# Releases are built with llvm-mingw 20260922 (msvcrt, i686-w64-mingw32-clang++), the
# compiler every in-game tested build was made with. With that compiler the output is
# byte-identical to the release, so you can check a release against this source.
# Any other 32-bit MinGW-w64 compiler works too: CXX=i686-w64-mingw32-g++ ./build.sh
#
#   ./build.sh            the ASI
#   ./build.sh --tests    also build/TS3.exe, the plug-in ABI test (run it on Windows or Wine)
set -eu
cd "$(dirname "$0")"

if [ -z "${CXX:-}" ]; then
    for c in i686-w64-mingw32-clang++ i686-w64-mingw32-g++; do
        if command -v "$c" >/dev/null 2>&1; then CXX=$c; break; fi
    done
fi
if [ -z "${CXX:-}" ]; then
    echo "No 32-bit MinGW-w64 compiler found. Install llvm-mingw or g++-mingw-w64-i686, or set CXX." >&2
    exit 1
fi

FLAGS="-std=c++17 -O2 -msse2 -mfpmath=sse -fno-exceptions -fno-rtti"
mkdir -p build
"$CXX" $FLAGS -Wall -Wextra -Wno-unused-parameter -shared -static -s -Wl,--no-insert-timestamp \
    -o build/RadioLeveler.asi src/radio_leveler.cpp
echo "built build/RadioLeveler.asi with $CXX"
if command -v sha256sum >/dev/null 2>&1; then
    (cd build && sha256sum RadioLeveler.asi | tee RadioLeveler.asi.sha256)
fi

if [ "${1:-}" = "--tests" ]; then
    "$CXX" $FLAGS -static -o build/TS3.exe tests/abi_test.cpp
    echo "built build/TS3.exe (run it from the build folder, next to RadioLeveler.asi)"
fi
