# SPDX-License-Identifier: MIT
# Copyright (c) 2026 thesammy58
# Written with Claude, Anthropic's AI model; see "Made with AI" in README.md.
"""Builds the player download: release/RadioLeveler-v<version>.zip

    python tools/make_release.py [path/to/RadioLeveler.asi]

The zip mirrors where the files go:
    Game/Bin/RadioLeveler.asi           -> The Sims 3/Game/Bin/
    Mods/Packages/RadioLeveler.package  -> Documents/Electronic Arts/The Sims 3/Mods/Packages/
plus README.md, CHANGELOG.md, LICENSE and the ASI's SHA-256. No ini is shipped: the ASI
writes a default RadioLeveler.ini on first run, so upgrading never overwrites your settings.
Entries get a fixed timestamp, so the same inputs always give the same zip."""
import hashlib, os, re, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    asi = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "build", "RadioLeveler.asi")
    src = open(os.path.join(ROOT, "src", "radio_leveler.cpp"), encoding="utf-8").read()
    version = re.search(r'#define RL_VERSION "([^"]+)"', src).group(1)
    data = open(asi, "rb").read()
    if data[:2] != b"MZ":
        sys.exit(f"{asi} is not a Windows DLL")
    sha = hashlib.sha256(data).hexdigest()

    def text(name):
        return open(os.path.join(ROOT, name), "rb").read().replace(b"\r\n", b"\n").replace(b"\n", b"\r\n")

    files = [
        ("Game/Bin/RadioLeveler.asi", data),
        ("Mods/Packages/RadioLeveler.package", open(os.path.join(ROOT, "package", "RadioLeveler.package"), "rb").read()),
        ("README.md", text("README.md")),
        ("CHANGELOG.md", text("CHANGELOG.md")),
        ("LICENSE", text("LICENSE")),
        ("RadioLeveler.asi.sha256", f"{sha}  RadioLeveler.asi\r\n".encode()),
    ]
    os.makedirs(os.path.join(ROOT, "release"), exist_ok=True)
    out = os.path.join(ROOT, "release", f"RadioLeveler-v{version}.zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, blob in files:
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, blob)
    print(f"wrote {out}")
    print(f"RadioLeveler.asi SHA-256 {sha}")


if __name__ == "__main__":
    main()
