# RadioLeveler

**Automatic loudness leveling for the radio in The Sims 3.**

Songs on the Sims 3 radio are nowhere near the same loudness. EA's own stations span more than 10 dB, and custom music is often louder still, so you end up reaching for the stereo's volume every few songs. RadioLeveler measures each song while it plays and steers it to the same loudness, much like the volume normalization on streaming services.

- **Covers every music player:** stereos, wired speakers, jukeboxes and boomboxes, on EA stations and Custom Music alike.
- **Song by song:** each song is measured as it plays, skips included, and changes are logged so you can see what it did.
- **Leaves the rest of the game alone:** no other game sound is affected, and your stereo's Low/Medium/High setting and the Music slider still work as usual.
- **Live A/B hotkey (Ctrl+Shift+L)** to hear the difference.
- **No game code patched.** It reuses an unused audio plug-in slot in the game's own sound engine.

> **Made with AI.** RadioLeveler was built with Claude, Anthropic's AI model. Claude did the reverse engineering of the game's audio engine, the leveling algorithm, all of the code and this documentation. thesammy58 directed the project, tested it in game and tuned the default settings. See [Made with AI](#made-with-ai).

## Requirements

- **The Sims 3, fully patched.** The EA App version (1.69.47) is tested in game. The Steam version was checked against its executable and needs no changes. Other versions are untested.
- **An ASI loader in `Game\Bin`.** For example [Ultimate ASI Loader](https://github.com/ThirteenAG/Ultimate-ASI-Loader/releases) or [dxwrapper](https://github.com/elishacloud/dxwrapper). If you already use other `.asi` mods, you have one.

## Install

1. Download `RadioLeveler-v1.3.0.zip` from the [Releases](../../releases) page and open it.
2. Copy everything in `Game\Bin\` into `The Sims 3\Game\Bin\`. On Steam that's `steamapps\common\The Sims 3\Game\Bin`.
3. Copy `Mods\Packages\RadioLeveler.package` into `Documents\Electronic Arts\The Sims 3\Mods\Packages\`.
4. Start the game and turn on a stereo. `Game\Bin\RadioLeveler.log` will get a line for every song.

Both the `.asi` and the `.package` are needed. With only one installed, the game plays exactly as vanilla.

**Uninstall:** delete `RadioLeveler.asi`, `RadioLeveler.ini` and `RadioLeveler.log` from `Game\Bin`, and the package from `Mods\Packages`.

## Settings

Settings live in `Game\Bin\RadioLeveler.ini`. The ASI creates the file on first run if it's missing. Changes are picked up while the game runs (within about 2 seconds), so you can alt-tab, edit and listen.

| Setting | Default | What it does |
|---|---|---|
| `Enabled` | `1` | `0` passes radio audio through untouched |
| `Strength` | `standard` | How hard songs are pulled together. See below. |
| `TargetLUFS` | `-16` | The loudness every song is steered to, before the stereo's own volume. Higher is louder overall (e.g. `-14`), lower is quieter (e.g. `-18`). |
| `MaxBoostDB` | `10` | The most a quiet song is turned up |
| `MaxCutDB` | `12` | The most a loud song is turned down |
| `LimiterCeilingDB` | `-1` | Peak ceiling for boosted songs; `0` turns the limiter off |
| `ToggleHotkey` | `Ctrl+Shift+L` | The A/B switch. Accepts Ctrl/Shift/Alt plus a letter, digit, F1–F24, Insert, Home, End, PageUp, PageDown, Delete, Pause or ScrollLock. `None` disables it. |
| `LogSongs` | `1` | Log a line when each song starts and ends |
| `LogIntervalSec` | `30` | Extra status line per playing radio every N seconds; `0` turns it off |

The defaults are the settings tuned in-game for this release.

### Strength

| | no leveling | `standard` (default) | `relaxed` | `light` | `subtle` |
|---|---|---|---|---|---|
| Song-to-song loudness spread (5th–95th percentile) | 4.5 dB | 0.6 dB | 0.9 dB | 1.6 dB | 1.8 dB |
| Loudest vs. quietest song | 9.7 dB | 1.3 dB | 1.6 dB | 2.2 dB | 2.5 dB |
| Loud/quiet contrast within a song (LRA, median) | 4.9 LU | 3.4 | 4.1 | 4.5 | 4.6 |

- **`standard`** pulls songs tightest and also evens out loud and quiet sections within a song, a bit like FM radio processing.
- **The lighter presets** keep more of each song's own dynamics and mainly fix the jumps between songs.
- **Pre-1.3 names still work:** `max` = standard, `strong` = relaxed, `balanced` = light, `gentle` = subtle.

The numbers come from 69 songs drawn at random from the EA stations plus custom MP3s, run through the exact code in the ASI. With skipping (songs cut after 20–60 s, the way the Skip interaction does it), `standard` brings the spread from 7.9 dB down to 1.2 dB.

### A/B hotkey

Press **Ctrl+Shift+L** in-game to switch leveling off and on mid-song.

- **Off means the game's original levels.** The leveler keeps measuring in the background and the switch is a short crossfade, so flipping back and forth compares the same moment of the song.
- **The log says how big a difference to expect,** e.g. `A/B: leveling OFF - original game levels (difference you should hear: radio #3 +6.0 dB)`.
- **It only reacts while the game window is focused,** and every game start begins with leveling on.

## Reading the log

```
radio #12 on (2ch 48000 Hz) | starting at +2.5 dB, carried over from the last song
radio #12 off | song measured -17.6 LUFS -> played at -16.0 LUFS (gain +1.6 dB)
```

- **"measured"** is how loud the song is in the game, which is what you'd hear without the mod.
- **"played at"** is what you actually heard.
- **The `#` counts sound voices, not stereos.** The game creates a new one for every song, so a single stereo shows up as #1, #2, #3… Each new song starts from the previous song's level.
- **Songs skipped within a few seconds** are logged as `too short to measure`.

## FAQ

**I can't hear any difference with the A/B hotkey.**
Check whether Windows **Loudness Equalization** is on (Control Panel → Sound → Playback → your device → Properties → Enhancements). It levels everything the PC plays, so it hides the difference. Also compare on a song whose log line shows a gain of several dB; corrections under about 2 dB are hard to hear in a quick switch.

**Does it change any other game sounds?**
No. Only the radio's voice chain includes the leveler: stereos, wired speakers, jukeboxes and boomboxes. TV, instruments, the UI and the world sound exactly as before.

**Does it work with Custom Music?**
Yes. Songs in the Custom station go through the same chain as EA's.

**Is it compatible with Sims3SettingsSetter, Sims3MonoModder, NRaas…?**
It was tested alongside Sims3SettingsSetter, Sims3MonoModder and several other ASI mods. RadioLeveler doesn't patch game code or scripts, so script mods don't interact with it. The package overrides one audio resource, the radio's "stereo" voice template, so the only possible conflict is another mod that replaces that same resource.

**The radio is louder or quieter overall than I'm used to.**
Change `TargetLUFS`. Each step of 1 is about 1 dB.

**What does it cost?**
About 0.1 % of one CPU core per playing radio, on the game's audio thread, and about 12 KB of memory each.

## Building from source

The game is 32-bit, so the ASI must be built for Win32 / i686.

- **`./build.sh`** (Linux, macOS or MSYS2) builds `build/RadioLeveler.asi` with MinGW-w64.
  - Releases use [llvm-mingw](https://github.com/mstorsjo/llvm-mingw/releases) 20260922 (msvcrt), the compiler every tested build was made with.
  - With that compiler the output is byte-identical to the release, so you can check a download against the source with the `.sha256` file in the zip.
  - Any other 32-bit MinGW-w64 also works, e.g. `CXX=i686-w64-mingw32-g++ ./build.sh`.
- **CMake:** `cmake --preset mingw32 && cmake --build --preset mingw32` gives the same result as `build.sh`. In Visual Studio 2022, open the folder and pick the `vs2022-win32` preset.
- **`build.bat`** builds with MSVC from an *x86 Native Tools Command Prompt*.

  The Visual Studio builds haven't been tested yet.
- **The package:** `python tools/make_package.py` regenerates `package/RadioLeveler.package` from the voice template text.
- **A release zip:** `python tools/make_release.py` packs `release/RadioLeveler-v<version>.zip`.
- **GitHub Actions** builds every push. Pushing a tag such as `v1.3.0` publishes a release built from that tag.

The tests, and how to measure the leveler with your own music, are in [tests/README.md](tests/README.md). How it works inside the game's audio engine is in [docs/TECHNICAL.md](docs/TECHNICAL.md), and the version history is in [CHANGELOG.md](CHANGELOG.md).

## Made with AI

RadioLeveler was made in a series of conversations with **Claude**, Anthropic's AI model, in October 2026. Who did what:

**Claude (AI)**
- Worked out how the radio's audio is produced, from the game's decompiled scripts, its sound resources and a memory dump of the running game, and found the unused audio plug-in slot the mod hooks.
- Designed the leveling algorithm and measured it offline on real songs.
- Wrote all of the code in this repository (the ASI, the package generator, the tests, the build files) and the documentation, including this README.

**Me (thesammy58)**
- Came up with the idea and supplied the game files, the reference mods and the memory dump.
- Tested every build in game, decided how it should behave, and tuned the default settings by ear.

**What's verified:** in game on the EA App build (1.69.47), alongside Sims3SettingsSetter, Sims3MonoModder and several other ASI mods. That covers song-by-song leveling, skips and the A/B hotkey. The Steam executable was checked to contain the same audio code.

**What isn't yet:** Steam and disc builds in game, and the Visual Studio builds.

Commits written by Claude carry a `Co-Authored-By: Claude` line. Issue reports are welcome.

## Credits

- **Sims3SettingsSetter and Sims3MonoModder:** their sources showed how ASI mods hook the game.
- **ts3.rebuild:** decompiled game scripts, used to trace how the radio plays music.
- **[vgmstream](https://github.com/vgmstream/vgmstream):** decoded EA's radio songs for the offline loudness tests.
- **ITU-R BS.1770 / EBU R128:** the loudness measurement standards the leveler is built on.

## License

[MIT](LICENSE) © 2026 thesammy58
